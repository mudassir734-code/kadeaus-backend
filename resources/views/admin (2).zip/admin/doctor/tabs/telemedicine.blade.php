<div class="tab-pane fade" id="v-pills-telemedicine" role="tabpanel" aria-labelledby="v-pills-telemedicine-tab">
    <div class="appointments mb-0">
        <div class="card doctor-card p-3">
            <div class="doctor-name text-dark text-sm">Dr.Victoria Ellis</div>
            <div class="options text-info font-weight-bold text-sm"> Upcoming</div>

            <div class="d-flex align-items-center mb-2">
                <img src="{{ asset('admin/assets/img/team-1.jpg" alt="Doctor') }}"
                    class="rounded-md border-radius-lg me-2" style="width: 100px; height: 100px;">
                <div>

                    <small class="text-muted">
                        <i class="fa-solid fa-users text-danger me-3"></i>Dentist<br>
                        <i class="fa-solid fa-hospital text-danger me-3"></i> Northwood General
                        Hospital
                        <br />
                        <i class="fa-solid fa-phone text-danger me-3"></i> Video Call
                    </small>
                </div>
            </div>
            <h6 class="mb-0 fw-bold">Instructions:</h6>
            <p>
                Please log in 10 minutes early and have your latest skin care products or
                medications handy.
            </p>
            <div class="text-center border-radius-lg p-3 " style="background-color: #CDEDFF;">
                <p class="mb-0"><i class="fa-solid fa-circle-info text-info text-lg"></i></p>
                <p class="mb-0">Please log in 10 minutes early and have your latest skin care
                    products or
                    medications handy.</p>
            </div>

        </div>
        <div class="card doctor-card p-3">
            <div class="doctor-name text-dark text-sm">Dr.Victoria Ellis</div>
            <div class="options text-info font-weight-bold text-sm"> Upcoming</div>

            <div class="d-flex align-items-center mb-2">
                <img src="{{ asset('admin/assets/img/team-1.jpg') }}" alt="Doctor"
                    class="rounded-md border-radius-lg me-2" style="width: 100px; height: 100px;">
                <div>

                    <small class="text-muted">
                        <i class="fa-solid fa-users text-danger me-3"></i>Dentist<br>
                        <i class="fa-solid fa-hospital text-danger me-3"></i> Northwood General
                        Hospital
                        <br />
                        <i class="fa-solid fa-phone text-danger me-3"></i> Video Call
                    </small>
                </div>
            </div>
            <h6 class="mb-0 fw-bold">Instructions:</h6>
            <p>
                Please log in 10 minutes early and have your latest skin care products or
                medications handy.
            </p>
            <div class="text-center border-radius-lg p-3 " style="background-color: #CDEDFF;">
                <p class="mb-0"><i class="fa-solid fa-circle-info text-info text-lg"></i></p>
                <p class="mb-0">Please log in 10 minutes early and have your latest skin care
                    products or
                    medications handy.</p>
            </div>

        </div>
        <div class="card doctor-card p-3">
            <div class="doctor-name text-dark text-sm">Dr.Victoria Ellis</div>
            <div class="options text-info font-weight-bold text-sm"> Upcoming</div>

            <div class="d-flex align-items-center mb-2">
                <img src="{{ asset('admin/assets/img/team-1.jpg') }}" alt="Doctor"
                    class="rounded-md border-radius-lg me-2" style="width: 100px; height: 100px;">
                <div>

                    <small class="text-muted">
                        <i class="fa-solid fa-users text-danger me-3"></i>Dentist<br>
                        <i class="fa-solid fa-hospital text-danger me-3"></i> Northwood General
                        Hospital
                        <br />
                        <i class="fa-solid fa-phone text-danger me-3"></i> Video Call
                    </small>
                </div>
            </div>
            <h6 class="mb-0 fw-bold">Instructions:</h6>
            <p>
                Please log in 10 minutes early and have your latest skin care products or
                medications handy.
            </p>
            <div class="text-center border-radius-lg p-3 " style="background-color: #CDEDFF;">
                <p class="mb-0"><i class="fa-solid fa-circle-info text-info text-lg"></i></p>
                <p class="mb-0">Please log in 10 minutes early and have your latest skin care
                    products or
                    medications handy.</p>
            </div>

        </div>
        <div class="card doctor-card p-3">
            <div class="doctor-name text-dark text-sm">Dr.Victoria Ellis</div>
            <div class="options text-info font-weight-bold text-sm"> Upcoming</div>

            <div class="d-flex align-items-center mb-2">
                <img src="{{ asset('admin/assets/img/team-1.jpg') }}" alt="Doctor"
                    class="rounded-md border-radius-lg me-2" style="width: 100px; height: 100px;">
                <div>

                    <small class="text-muted">
                        <i class="fa-solid fa-users text-danger me-3"></i>Dentist<br>
                        <i class="fa-solid fa-hospital text-danger me-3"></i> Northwood General
                        Hospital
                        <br />
                        <i class="fa-solid fa-phone text-danger me-3"></i> Video Call
                    </small>
                </div>
            </div>
            <h6 class="mb-0 fw-bold">Instructions:</h6>
            <p>
                Please log in 10 minutes early and have your latest skin care products or
                medications handy.
            </p>
            <div class="text-center border-radius-lg p-3 " style="background-color: #CDEDFF;">
                <p class="mb-0"><i class="fa-solid fa-circle-info text-info text-lg"></i></p>
                <p class="mb-0">Please log in 10 minutes early and have your latest skin care
                    products or
                    medications handy.</p>
            </div>

        </div>

    </div>
</div>
